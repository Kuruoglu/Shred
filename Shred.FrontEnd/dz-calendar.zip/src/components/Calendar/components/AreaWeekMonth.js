import React from 'react';
import styles from './AreaWeekMonth.module.sass';

class  AreaWeekMonth extends React.Component {
    
    render () {
      
        return (
            <>
            {this.props.isOpen && 
            <div className={styles.container}>            
            <button onClick={this.props.chengeWeek} className={styles.button}>This week</button>
            <button onClick={this.props.chengeMonth} className={styles.button}>This month</button>  
        </div>}
        </>
        );
    }
}


export default AreaWeekMonth;